local PeckerCheckerTester = LibStub("AceAddon-3.0"):NewAddon(
    "PeckerCheckerTester",
    "AceConsole-3.0",
    "AceEvent-3.0",
    "AceComm-3.0"
)


function PeckerCheckerTester:OnEnable()
    self:Print("Thank you for testing the PeckerChecker!")
    self:Print("Use /pp to check the pecker of yourself.")
    self:Print("Use /pt to check the pecker of your target.")

    self:SendCommMessage(
        "PC_REG",
        UnitGUID("player"),
        "GUILD"
    )
end


-- PeckerRNG creates a deterministic hash: the same GUID and secret produce the same result.
local peckerSecret = 420

function PeckerCheckerTester:GeneratePecker(guid)
    if not guid then
        return nil
    end

    local hash = peckerSecret
    local modulus = 2147483647

    -- Hash every byte of the GUID.
    for i = 1, #guid do
        hash = (hash * 31 + string.byte(guid, i)) % modulus
    end

    -- Base score: 1-15.
    return (hash % 15) + 1
end


function PeckerCheckerTester:GetTargetPecker()
    if UnitGUID("target") ~= nil then
        self:Print(self:GeneratePecker(UnitGUID("target")))
    end
end


function PeckerCheckerTester:GetPlayerPecker()
    self:Print(self:GeneratePecker(UnitGUID("player")))
end


PeckerCheckerTester:RegisterChatCommand("pt", "GetTargetPecker")
PeckerCheckerTester:RegisterChatCommand("pp", "GetPlayerPecker")
